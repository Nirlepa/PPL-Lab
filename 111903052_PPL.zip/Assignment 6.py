# Classes - Shapes

import turtle

screen = turtle.getscreen()
root = turtle.Turtle()


class shape:
    def __init__(self, side=0, length = 0):
        self.side = side
        self.length = length

class polygon(shape):
    def defination(self):
        print("A polygon is a closed shape figure that has minimum of three sides and three vertices")

class triangle(polygon):
    def draw(self):
        root.fillcolor("red")
        root.begin_fill()

        for i in range (0, self.side):
            root.fd(self.length)
            root.lt(120)

        root.end_fill()


class square(polygon):
    def draw(self):
        root.fillcolor("green")
        root.begin_fill()
        for i in range(0,self.side):
            root.fd(self.length)
            root.rt(90)
        root.end_fill()

class pentagon(polygon):
    def draw(self):
        root.fillcolor("blue")
        root.begin_fill()
        for i in range(0,self.side):
            root.fd(self.length)
            root.lt(72)
        root.end_fill()

class hexagon(polygon):
    def draw(self):
        root.fillcolor("black")
        root.begin_fill()
        for i in range(0,self.side):
            root.fd(self.length)
            root.lt(60)
        root.end_fill()

class octagon(polygon):
    def draw(self):
        root.fillcolor("pink")
        root.begin_fill()
        for i in range(0,self.side):
            root.fd(self.length)
            root.lt(45)
        root.end_fill()

class rectangle(shape):
    def __init__(self, breadth):
        self.breadth = breadth
        shape.__init__(self,4,100)

    def draw(self):
        root.fillcolor("orange")
        root.begin_fill()
        for i in range(0,2):
            root.fd(self.length)
            root.lt(90)

            root.fd(self.breadth)
            root.lt(90)
        root.end_fill()

class circle(shape):
    def __init__(self, radius):
        self.radius = radius

    def draw(self):
        turtle.circle(self.radius)

sp1 = hexagon(8, 50)
sp1.draw()

