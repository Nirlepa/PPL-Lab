#Class - Animals


class Animals:
    legs = 4
    eyes = 2
    def __init__(self, kind, place):
        self.kind = kind
        self.place = place



class Domestic_Animals(Animals):
    def __init__(self):
        Animals.__init__(self,'Domestic', 'Near Human Habitat')


class wild_Animals(Animals):
    def __init__(self):
        Animals.__init__(self,'Wild', 'jungle')


class carnivores(Animals):
    def food(self):
        print("Only Meat")

class herbivores(Animals):
    def food(self):
        print("Exclusively Plant")

class omnivores(Animals):
    def food(self):
        print("both plants and meat")

class Dog(Domestic_Animals, carnivores):
    def sound(self):
        print("Woof")

    def use(self):
        print("Police Dogs, assistance Dogs, hunting Dogs")


class Cat(Domestic_Animals, omnivores):
    def sound(self):
        print("Meow")

    def use(self):
        print("Hunt rodents, Purring helps to heal bones and muscles")

class tiger(wild_Animals, carnivores):
    def sound(self):
        print("growl")

    def colour(self):
        print("Orange, white")


class lion(wild_Animals, carnivores):
    def sound(self):
        print("Roar")

    def colour(self):
        print("Yellow")

class deer(wild_Animals, herbivores):
    def sound(self):
        print("Bell")

    def colour(self):
        print("Brown")


class horse():
    def sound(self):
        print("snort, whinny")

    def colour(self):
        print("Multicolour")


class cows(Domestic_Animals, herbivores):
    def sound(self):
        print("moo")

    def colour(self):
        print("Multicolour")


class Sheep(Domestic_Animals, herbivores):
    def sound(self):
        print("bleat")

    def colour(self):
        print("Grey , white, black")


class Bears(wild_Animals, omnivores):
    def sound(self):
        print("growl")

    def colour(self):
        print("Multicolour")


class fox(wild_Animals, carnivores):
    def sound(self):
        print("bark")

    def colour(self):
        print("black, brown,")

tom = Dog()

print(tom.__dict__)
tom.sound()
tom.use()

max = tiger()

max.food()
max.colour()
max.sound()
print(max.__dict__)