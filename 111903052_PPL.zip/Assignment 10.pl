teaches_subject(jatin_Majethia, math).
teaches_subject(vaibhav_Khatavkar, ppl).
teaches_subject(sumit_hirve, ppl).
teaches_subject(shrida_kalamkar, dsa).
teaches_subject(ashwini_matange, dsa).
teaches_subject(pravin_pawar, dld).
teaches_subject(vibhavari, dsgt).
teaches_subject(sandip_hawante, fcs).
teaches_subject(jagnnath_aghav, dtl).
ha
department_subject(math_dep, math).
department_subject(comp_dep, ppl).
department_subject(comp_dep, dsa).
department_subject(comp_dep, fcs).
department_subject(comp_dep, dld).
department_subject(comp_dep, dsgt).
department_subject(comp_dep, dtl).

has_students(comp_dep, 111903001).
has_students(comp_dep, 111903002).
has_students(comp_dep, 111903003).
has_students(comp_dep, 111903004).
has_students(comp_dep, 111903005).
has_students(comp_dep, 111903006).
has_students(comp_dep, 111903007).
has_students(comp_dep, 111903008).
has_students(comp_dep, 111903009).
has_students(comp_dep, 111903010).


has_faculty(D,F):-teaches_subject(F,S),department_subject(D,S).
studies_subject(ST,SB) :- has_students(D,ST) , department_subject(D,SB).
studies_under(S,F) :- has_students(D,S) ,department_subject(D,SB) , teaches_subject(F,SB).


